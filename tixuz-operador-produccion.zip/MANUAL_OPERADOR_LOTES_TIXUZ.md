# Manual del operador de lotes - Tixuz Autos

## Objetivo del trabajo

Conseguir lotes de autos reales para invitarlos a publicar gratis como **lotes fundadores de Tixuz Autos**.

El trabajo diario es:

1. Buscar lotes por ciudad.
2. Guardarlos en el panel de Prospectos.
3. Mandar el mensaje preparado por WhatsApp.
4. Marcar seguimiento.
5. Si aceptan, cargar su inventario para revisión.

## Acceso

1. Abrir Tixuz Autos:

   `https://tixuzautos.com`

2. Bajar al footer y entrar en **Operador**.

3. Escribir el PIN que te entregue Tixuz Autos.

4. Entrar a **Prospectos**.

## Flujo fácil

Dentro del panel usar los botones en orden:

1. **Buscar lotes**
   - Escribir primero la ciudad en **Ciudad foco**.
   - Ejemplo: Guadalajara, Monterrey, Puebla, CDMX.
   - Presionar **1 Buscar lotes**.

2. **Copiar datos desde Google Maps**
   - Abrir una ficha de lote.
   - Copiar el texto visible donde salga nombre, teléfono, dirección y link.
   - No importa si el texto viene desordenado.

3. **Pegar e importar**
   - Volver a Tixuz.
   - Presionar **2 Pegar e importar**.
   - El sistema detecta el nombre, teléfono y fuente.

4. **Preparar siguiente**
   - Presionar **3 Preparar siguiente**.
   - Se abre WhatsApp con el mensaje listo.
   - Revisar que el mensaje se vea bien.
   - Enviar manualmente.

5. **Ya lo envié**
   - Volver al panel.
   - Presionar **4 Ya lo envié**.
   - El prospecto queda como contactado y con seguimiento para mañana.

## Estados

- **Pendiente:** todavía no se le mandó mensaje.
- **Contactado:** ya se le mandó mensaje.
- **Interesado:** respondió que sí o pidió información.
- **No:** dijo que no, no contestó mal, no quiere, o no corresponde.

## Seguimiento

Cada día revisar el filtro **Toca hoy**.

Si toca seguimiento:

1. Presionar **Preparar siguiente** o abrir el prospecto.
2. Mandar el mensaje de seguimiento.
3. Marcar otra fecha: **Mañana** o **3 días**.

## Cuando un lote diga que sí

1. Marcarlo como **Interesado**.
2. Presionar **Inventario**.
3. Pedir al lote:
   - Fotos de cada auto.
   - Año.
   - Marca.
   - Modelo.
   - Precio.
   - Kilometraje.
   - Ciudad.
   - WhatsApp de contacto.
4. Pegar el texto, Excel, lista o datos que mande.
5. Revisar que los autos estén bien.
6. Enviar a revisión.

## Reglas importantes

- No mandar mensajes automáticos masivos.
- No insistir si dicen que no.
- No publicar autos sin autorización del lote.
- No inventar precios, años, fotos ni teléfonos.
- Usar solo datos públicos de negocios o lotes.
- Revisar el mensaje antes de enviarlo.
- Si alguien se molesta, marcar **No** y no volver a escribir.

## Mensaje base

El sistema ya prepara el mensaje. No hace falta escribirlo desde cero.

La idea principal es:

> Somos Tixuz Autos, del programa de YouTube. Estamos invitando lotes fundadores para publicar gratis por lanzamiento, sin comisión, con contacto directo a WhatsApp.

## Entrega diaria sugerida

Al terminar el día:

1. Exportar CSV.
2. Reportar:
   - Ciudad trabajada.
   - Prospectos nuevos.
   - Mensajes enviados.
   - Interesados.
   - Lotes que dijeron que no.
   - Inventarios recibidos.

## Meta simple

Una buena jornada no es mandar miles de mensajes. Es trabajar bien:

- Prospectos reales.
- Teléfonos correctos.
- Mensajes revisados.
- Seguimiento ordenado.
- Interesados cargados rápido.
