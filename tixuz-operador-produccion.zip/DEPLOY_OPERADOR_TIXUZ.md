# Operador publicado en tixuzautos.com

El panel quedó integrado en el sitio con botón discreto **Operador** en el footer.

Paquete generado para subir:

- `tixuz-operador-produccion.zip`

Para producción necesita estas variables en Netlify:

- `OPS_PIN`: PIN que usará el operador.
- `OPS_JWT_SECRET`: secreto largo para firmar sesión de operador.

La función que valida el PIN es:

- `netlify/functions/ops-auth.mjs`

El HTML ya no contiene el PIN. El desbloqueo llama a:

- `/.netlify/functions/ops-auth`

## Estado

Publicado en producción:

- `https://tixuzautos.com`

Variables configuradas en Netlify:

- `OPS_PIN`
- `OPS_JWT_SECRET`

Verificado:

- El sitio público muestra **Operador** en el footer.
- No muestra **Prospectos** públicamente.
- El PIN desbloquea el panel.
- El panel abre **Prospectos de lotes** con **Modo fácil**.
- Las funciones existentes siguen respondiendo.
